import { useCallback, useEffect, useRef, useState } from "react";
import { pb } from "./lib/pb";

const ring = "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gg-accent";
const btn = `min-h-11 rounded-lg border border-gg-line2 bg-gg-panel2 px-4 text-sm font-medium text-gg-fg hover:bg-gg-raised ${ring}`;
const primary = `min-h-11 rounded-lg bg-gg-accent px-4 text-sm font-semibold text-gg-onaccent hover:bg-gg-accent2 ${ring}`;
const input = `min-h-11 w-full rounded-lg border border-gg-line2 bg-gg-base px-3 text-sm text-gg-fg placeholder:text-gg-fg3 ${ring}`;
const COLORS = ["#c0392b", "#1f6f8b", "#6a3fb5", "#2e7d32", "#a0522d", "#b03a79", "#37474f", "#8a6d00"];
const colorFor = (s) => COLORS[[...(s || "")].reduce((a, c) => a + c.charCodeAt(0), 0) % COLORS.length];
const nameOf = (u) => ((u?.email || "").endsWith("@users.giggleos.app") ? u.email.split("@")[0] : u?.name || (u?.email || "").split("@")[0] || "someone");
const time = (iso) => {
  const d = new Date(iso.replace(" ", "T"));
  const t = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString([], { day: "numeric", month: "short" }) + " " + t;
};

export default function ChatApp({ user }) {
  const me = nameOf(user);
  const isAdmin = user?.role === "admin";
  const [rooms, setRooms] = useState(null);
  const [cur, setCur] = useState(null);
  const [msgs, setMsgs] = useState(null);
  const [draft, setDraft] = useState("");
  const [err, setErr] = useState("");
  const [adding, setAdding] = useState(false);
  const [rn, setRn] = useState("");
  const [rt, setRt] = useState("");
  const [showRooms, setShowRooms] = useState(true);
  const [busy, setBusy] = useState(false);
  const [making, setMaking] = useState(false);
  const [dming, setDming] = useState(false);
  const curRef = useRef(null);
  curRef.current = cur;
  const endRef = useRef(null);
  const stick = useRef(true);
  const listRef = useRef(null);
  const seeded = useRef(false);
  const meKey = me.toLowerCase();
  const [priv, setPriv] = useState(false);
  const [invite, setInvite] = useState("");
  const [dmOpen, setDmOpen] = useState(false);
  const [dmName, setDmName] = useState("");
  const label = (r) => (r.dm ? (r.name.split("+").find((x) => x !== meKey) || meKey) : r.name);

  useEffect(() => {
    (async () => {
      try {
        await pb.collection("chat_people").getFirstListItem(pb.filter("user = {:u}", { u: user.id }), { requestKey: null });
      } catch {
        try { await pb.collection("chat_people").create({ user: user.id, username: meKey }, { requestKey: null }); } catch { /* already there */ }
      }
    })();
  }, [user.id, meKey]);

  const findPeople = async (raw) => {
    const names = [...new Set(raw.split(/[,\s]+/).map((x) => x.trim().replace(/^@/, "").toLowerCase()).filter(Boolean))].slice(0, 20);
    const ids = [];
    for (const n of names) {
      if (n === meKey) continue;
      try {
        const p = await pb.collection("chat_people").getFirstListItem(pb.filter("username = {:n}", { n }), { requestKey: null });
        ids.push(p.user);
      } catch {
        throw new Error(`Nobody called "${n}" has opened Chat yet. Ask them to open it once, then try again.`);
      }
    }
    return ids;
  };

  const loadRooms = useCallback(async () => {
    try {
      let list = await pb.collection("chat_rooms").getFullList({ sort: "created", requestKey: null });
      if (!list.length && !seeded.current) {
        seeded.current = true;
        try {
          await pb.collection("chat_rooms").create({ name: "general", topic: "Say hello to everyone", owner: user.id }, { requestKey: null });
          list = await pb.collection("chat_rooms").getFullList({ sort: "created", requestKey: null });
        } catch { /* someone else created it */ }
      }
      setRooms(list);
      setErr((x) => (x.startsWith("Couldn't load the rooms") ? "" : x));
      setCur((c) => (c && list.some((r) => r.id === c) ? c : list[0]?.id || null));
    } catch {
      setRooms((r) => r || []);
      setErr("Couldn't load the rooms. Check your connection and try again.");
    }
  }, [user.id]);

  useEffect(() => {
    loadRooms();
    const t = setInterval(loadRooms, 15000);
    return () => clearInterval(t);
  }, [loadRooms]);

  useEffect(() => {
    setMsgs(null);
    stick.current = true;
    if (!cur) return;
    let alive = true;
    const load = async () => {
      try {
        const res = await pb.collection("chat_messages").getList(1, 150, { filter: pb.filter("room = {:r}", { r: cur }), sort: "-created", requestKey: null });
        if (alive) { const items = res.items.reverse(); setMsgs((old) => (old && old.length === items.length && old.length && old[old.length - 1].id === items[items.length - 1].id && old[0].id === items[0].id ? old : items)); setErr(""); }
      } catch {
        if (alive) setMsgs((m) => m || []);
      }
    };
    load();
    const t = setInterval(load, 3000);
    return () => { alive = false; clearInterval(t); };
  }, [cur]);

  useEffect(() => {
    if (stick.current) endRef.current?.scrollIntoView({ block: "end" });
  }, [msgs]);

  const onScroll = () => {
    const el = listRef.current;
    if (el) stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  };

  const send = async (e) => {
    e?.preventDefault();
    const text = draft.trim();
    if (!text || !cur || busy) return;
    setBusy(true);
    try {
      const rec = await pb.collection("chat_messages").create({ room: cur, author: user.id, authorName: me, text: text.slice(0, 2000) }, { requestKey: null });
      setDraft("");
      stick.current = true;
      setMsgs((m) => (curRef.current === rec.room && !(m || []).some((x) => x.id === rec.id) ? [...(m || []), rec] : m));
      setErr("");
    } catch {
      setErr("Your message didn't send. Please try again.");
    }
    setBusy(false);
  };

  const addRoom = async (e) => {
    e.preventDefault();
    const name = rn.trim().toLowerCase().replace(/[^a-z0-9-_ ]/g, "").replace(/\s+/g, "-").slice(0, 30);
    if (making) return;
    setErr("");
    if (!name) return setErr("Give the room a name using letters or numbers.");
    if (!priv && rooms?.some((r) => !r.private && r.name === name)) return setErr("A room with that name already exists.");
    setMaking(true);
    try {
      const others = priv ? await findPeople(invite) : [];
      const data = { name, topic: rt.trim().slice(0, 140), owner: user.id };
      if (priv) Object.assign(data, { private: true, members: [user.id, ...others] });
      const rec = await pb.collection("chat_rooms").create(data, { requestKey: null });
      setRooms((r) => [...(r || []), rec]);
      setCur(rec.id);
      setAdding(false); setRn(""); setRt(""); setInvite(""); setPriv(false); setErr(""); setShowRooms(false);
    } catch (ex) {
      setErr(ex?.message?.startsWith("Nobody") ? ex.message : "Couldn't create the room. Please check the name and try again.");
    } finally {
      setMaking(false);
    }
  };

  const startDm = async (e) => {
    e.preventDefault();
    const n = dmName.trim().replace(/^@/, "").toLowerCase();
    setErr("");
    if (!n) return setErr("Type the username of the person you want to message.");
    if (n === meKey) return setErr("That's you! Pick someone else.");
    if (dming) return;
    setDming(true);
    try {
      const [other] = await findPeople(n);
      const name = [meKey, n].sort().join("+");
      let rec = rooms?.find((r) => r.dm && r.name === name);
      if (!rec) {
        rec = await pb.collection("chat_rooms").create({ name, owner: user.id, private: true, dm: true, members: [user.id, other] }, { requestKey: null });
        setRooms((r) => [...(r || []), rec]);
      }
      setCur(rec.id); setDmOpen(false); setDmName(""); setErr(""); setShowRooms(false);
    } catch (ex) {
      setErr(ex?.message?.startsWith("Nobody") ? ex.message : "Couldn't start that conversation. Please try again.");
    } finally {
      setDming(false);
    }
  };

  const delRoom = async (r) => {
    if (!confirm(`Delete ${label(r)} and all its messages?`)) return;
    try {
      await pb.collection("chat_rooms").delete(r.id, { requestKey: null });
      setRooms((l) => l.filter((x) => x.id !== r.id));
      if (cur === r.id) setCur(null);
      loadRooms();
    } catch {
      setErr("Couldn't delete that room.");
    }
  };

  const delMsg = async (m) => {
    try {
      await pb.collection("chat_messages").delete(m.id, { requestKey: null });
      setMsgs((l) => l.filter((x) => x.id !== m.id));
    } catch {
      setErr("Couldn't delete that message.");
    }
  };

  const room = rooms?.find((r) => r.id === cur);

  return (
    <div className="flex h-full min-h-0 flex-col bg-gg-panel text-gg-fg md:flex-row">
      <aside className={`${showRooms ? "flex" : "hidden"} max-h-[55%] min-h-0 shrink-0 flex-col border-b border-gg-line bg-gg-panel2 md:flex md:max-h-none md:w-56 md:border-b-0 md:border-r`}>
        <div className="flex max-h-[70%] shrink-0 flex-col overflow-y-auto">
        <div className="flex items-center justify-between gap-2 p-2">
          <h2 className="px-1 text-sm font-semibold">Rooms</h2>
          <div className="flex gap-1">
            <button type="button" className={btn} onClick={() => { setDmOpen((a) => !a); setAdding(false); setErr(""); }} aria-expanded={dmOpen}>{dmOpen ? "Cancel" : "Message"}</button>
            <button type="button" className={btn} onClick={() => { setAdding((a) => !a); setDmOpen(false); setErr(""); }} aria-expanded={adding}>{adding ? "Cancel" : "+ Room"}</button>
          </div>
        </div>
        {dmOpen && (
          <form onSubmit={startDm} className="grid gap-2 border-y border-gg-line p-2">
            <label className="grid gap-1 text-xs text-gg-fg2">Their username
              <input className={input} value={dmName} onChange={(e) => setDmName(e.target.value)} maxLength={30} placeholder="username" autoComplete="off" />
            </label>
            <button className={primary} disabled={dming}>{dming ? "Starting…" : "Start chatting"}</button>
          </form>
        )}
        {adding && (
          <form onSubmit={addRoom} className="grid gap-2 border-y border-gg-line p-2">
            <label className="grid gap-1 text-xs text-gg-fg2">Room name
              <input className={input} value={rn} onChange={(e) => setRn(e.target.value)} maxLength={30} placeholder="movie-night" />
            </label>
            <label className="grid gap-1 text-xs text-gg-fg2">What's it about? (optional)
              <input className={input} value={rt} onChange={(e) => setRt(e.target.value)} maxLength={140} />
            </label>
            <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={priv} onChange={(e) => setPriv(e.target.checked)} className="size-5" /> Private (invite only)</label>
            {priv && (
              <label className="grid gap-1 text-xs text-gg-fg2">Who can join? Usernames, separated by commas
                <input className={input} value={invite} onChange={(e) => setInvite(e.target.value)} placeholder="sam, jo" autoComplete="off" />
              </label>
            )}
            <button className={primary} disabled={making}>{making ? "Creating…" : "Create room"}</button>
          </form>
        )}
        {(adding || dmOpen) && err && <p role="alert" className="border-b border-gg-line px-3 py-2 text-sm text-gg-error">{err}</p>}
        </div>
        <nav aria-label="Chat rooms" className="min-h-0 flex-1 overflow-y-auto p-1">
          {rooms === null && <p className="p-2 text-sm text-gg-fg2">Loading rooms…</p>}
          {rooms && [...rooms].sort((a, b) => (a.dm - b.dm) || (a.private - b.private) || a.created.localeCompare(b.created)).map((r, i, all) => (
            <div key={r.id}>
              {(i === 0 || all[i - 1].dm !== r.dm || all[i - 1].private !== r.private) && (
                <p className="px-3 pb-1 pt-2 text-xs font-semibold uppercase text-gg-fg2">{r.dm ? "Direct messages" : r.private ? "Private rooms" : "Public rooms"}</p>
              )}
              <div className="flex items-center">
              <button type="button" onClick={() => { setCur(r.id); setShowRooms(false); }} aria-current={r.id === cur ? "true" : undefined}
                className={`min-h-11 min-w-0 flex-1 truncate rounded-lg px-3 text-left text-sm ${ring} ${r.id === cur ? "bg-gg-accent font-semibold text-gg-onaccent" : "hover:bg-gg-raised"}`}>{r.dm ? "@ " : r.private ? "🔒 " : "# "}{label(r)}</button>
              {(r.owner === user.id || isAdmin) && (
                <button type="button" onClick={() => delRoom(r)} className={`grid size-11 shrink-0 place-items-center rounded-lg text-gg-fg2 hover:bg-gg-raised hover:text-gg-error ${ring}`} aria-label={`Delete ${label(r)}`}>✕</button>
              )}
              </div>
            </div>
          ))}
        </nav>
      </aside>

      <section className="flex min-h-0 min-w-0 flex-1 flex-col" aria-label="Conversation">
        <header className="flex items-center gap-2 border-b border-gg-line px-3 py-2">
          <button type="button" className={`${btn} md:hidden`} onClick={() => setShowRooms((s) => !s)} aria-expanded={showRooms}>Rooms</button>
          <div className="min-w-0">
            <h2 className="truncate text-sm font-semibold">{room ? (room.dm ? "@ " : room.private ? "🔒 " : "# ") + label(room) : "no room"}</h2>
            {room?.topic && <p className="truncate text-xs text-gg-fg2">{room.topic}</p>}
          </div>
        </header>
        <div ref={listRef} onScroll={onScroll} className="min-h-0 flex-1 overflow-y-auto p-3" role="log" aria-live="polite" aria-label="Messages">
          {!room && rooms && <p className="text-sm text-gg-fg2">Pick a room, or press <strong>+ Room</strong> to start one.</p>}
          {room && msgs === null && <p className="text-sm text-gg-fg2">Loading messages…</p>}
          {room && msgs?.length === 0 && <p className="text-sm text-gg-fg2">No messages yet. Say hello!</p>}
          <ul className="grid gap-3">
            {msgs?.map((m) => (
              <li key={m.id} className="group flex gap-2">
                <span aria-hidden="true" className="grid size-9 shrink-0 place-items-center rounded-full text-sm font-bold text-white" style={{ background: colorFor(m.authorName) }}>{(m.authorName || "?")[0].toUpperCase()}</span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm"><strong style={{ color: colorFor(m.authorName) }}>{m.authorName || "someone"}</strong> <span className="text-xs text-gg-fg2">{time(m.created)}</span></p>
                  <p className="whitespace-pre-wrap break-words text-sm">{m.text}</p>
                </div>
                {(m.author === user.id || isAdmin) && (
                  <button type="button" onClick={() => delMsg(m)} className={`grid size-11 shrink-0 place-items-center rounded-lg text-gg-fg2 hover:text-gg-error ${ring}`} aria-label="Delete this message">✕</button>
                )}
              </li>
            ))}
          </ul>
          <div ref={endRef} />
        </div>
        {err && !(adding || dmOpen) && <p role="alert" className="border-t border-gg-line px-3 py-1 text-sm text-gg-error">{err}</p>}
        <form onSubmit={send} className="flex gap-2 border-t border-gg-line p-2">
          <label className="min-w-0 flex-1"><span className="sr-only">Message</span>
            <textarea rows={1} value={draft} maxLength={2000} disabled={!room}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) send(e); }}
              placeholder={room ? `Message ${label(room)} (Enter to send)` : "Pick a room first"}
              className={`${input} max-h-32 resize-none py-2.5`} />
          </label>
          <button className={primary} disabled={!room || !draft.trim() || busy}>Send</button>
        </form>
      </section>
    </div>
  );
}
