import { useState } from "react";
import { pb } from "./lib/pb.js";

const ring = "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gg-accent";
const btn = `min-h-11 border border-gg-line2 bg-gg-raised px-3 text-sm font-semibold text-gg-fg ${ring} disabled:opacity-50`;
const hash = (t) => { let h = 5381; for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0; return String(h) + ":" + t.length; };

const API = "https://api.github.com/repos/ariintheam-coder/Giggle-OS-Apps/contents/Apps";
const RAW = "https://raw.githubusercontent.com/ariintheam-coder/Giggle-OS-Apps/HEAD/Apps/";
const prettify = (f) => f.replace(/\.html?$/i, "").replace(/[-_]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^./, (c) => c.toUpperCase());

export default function Store({ catalog, prefs, setPrefs, extras = [], setExtras = () => {} }) {
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState({});
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");
  const installed = new Set(prefs.installed || []);

  const setInstalled = (id, on) => setPrefs((p) => {
    const cur = new Set(p.installed || []);
    if (on) cur.add(id); else cur.delete(id);
    return { ...p, installed: [...cur], folders: on ? p.folders : (p.folders || []).map((f) => ({ ...f, apps: f.apps.filter((x) => x !== id) })) };
  });

  async function loadOverride(id) {
    try { const rec = await pb.collection("os_data").getFirstListItem(`appId="app-src-${id}"`, { requestKey: null }); const r = await fetch(pb.files.getURL(rec, rec.blob)); return { rec, data: r.ok ? await r.json() : null }; } catch { return { rec: null, data: null }; }
  }
  async function check(app) {
    const res = await fetch(app.gh, { cache: "no-store" });
    if (!res.ok) throw new Error("GitHub didn't answer");
    const fresh = await res.text();
    if (fresh.length < 500 || !/<html|<!doctype/i.test(fresh)) throw new Error("that file isn't a web app");
    const { rec, data } = await loadOverride(app.id);
    const current = data?.html || await (await fetch(app.src)).text();
    if (hash(current) === hash(fresh)) return "Already up to date.";
    const fd = new FormData();
    fd.append("blob", new Blob([JSON.stringify({ html: fresh, hash: hash(fresh), at: Date.now() })], { type: "application/json" }), "data.json");
    if (rec) await pb.collection("os_data").update(rec.id, fd, { requestKey: null });
    else { fd.append("owner", (pb.authStore.record || pb.authStore.model).id); fd.append("appId", "app-src-" + app.id); await pb.collection("os_data").create(fd, { requestKey: null }); }
    return "Updated to the latest version. Reopen the app to use it.";
  }
  const targets = (a) => a.subs || (a.gh ? [a] : []);
  const say = (a, t) => setMsg((m) => ({ ...m, [a.id]: t }));

  // Saves one self-contained copy of the app (icon inlined, nothing fetched from the site) so it opens from a phone's Downloads.
  const saveCopy = async (a) => {
    say(a, "Preparing your copy…");
    try {
      const res = await fetch(a.src, { cache: "no-cache" });
      if (!res.ok) throw new Error("fetch");
      let html = await res.text();
      let icon = "";
      try {
        const ib = await (await fetch("/static/apps/sonardeck-192.png")).blob();
        icon = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(ib); });
      } catch { /* icon is optional */ }
      html = html.replace(/<link rel="manifest"[^>]*>\s*/g, "");
      html = icon ? html.replace(/(<link rel="apple-touch-icon" href=")[^"]*(")/, "$1" + icon + "$2") : html.replace(/<link rel="apple-touch-icon"[^>]*>\s*/g, "");
      const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
      const el = document.createElement("a");
      el.href = url; el.download = a.download; document.body.appendChild(el); el.click(); el.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      say(a, "Saved as " + a.download + ". Open it from your Downloads and choose Chrome. It works with no internet.");
    } catch {
      say(a, "Couldn't prepare the copy. Check your connection and try again.");
    }
  };
  async function update(app) {
    say(app, "Checking GitHub…");
    let ok = 0, same = 0, bad = "";
    for (const t of targets(app)) {
      try { const r = await check(t); if (r.startsWith("Already")) same++; else ok++; }
      catch (e) { bad = e.message || "try again"; }
    }
    const n = targets(app).length;
    if (ok) say(app, (n > 1 ? ok + " of " + n + " updated" : "Updated to the latest version") + ". Reopen to use " + (n > 1 ? "them" : "it") + "." + (bad ? " Some couldn't update: " + bad : ""));
    else if (bad) say(app, "Couldn't update: " + bad);
    else say(app, "Already up to date.");
  }
  async function revert(app) {
    say(app, "Restoring…");
    try {
      let n = 0;
      for (const t of targets(app)) { const { rec } = await loadOverride(t.id); if (rec) { await pb.collection("os_data").delete(rec.id, { requestKey: null }); n++; } }
      say(app, n ? "Back to the built-in version. Reopen to use it." : "Already using the built-in version.");
    } catch { say(app, "Couldn't restore. Try again."); }
  }
  async function saveExtras(list) {
    const fd = new FormData();
    fd.append("blob", new Blob([JSON.stringify(list)], { type: "application/json" }), "data.json");
    try {
      const rec = await pb.collection("os_data").getFirstListItem('appId="store-extras"', { requestKey: null });
      await pb.collection("os_data").update(rec.id, fd, { requestKey: null });
    } catch {
      fd.append("owner", (pb.authStore.record || pb.authStore.model).id); fd.append("appId", "store-extras");
      await pb.collection("os_data").create(fd, { requestKey: null });
    }
  }
  async function discover() {
    const res = await fetch(API, { cache: "no-store" });
    if (!res.ok) throw new Error("couldn't read the GitHub page");
    const files = (await res.json()).filter((f) => f.type === "file" && /\.html?$/i.test(f.name));
    const known = new Set([...catalog.flatMap((a) => (a.subs || [a]).map((t) => t.gh)), ...extras.map((e) => RAW + e.file)].filter(Boolean));
    const fresh = files.filter((f) => !known.has(RAW + f.name) && !/poke/i.test(f.name));
    const added = [];
    for (const f of fresh) {
      const id = "x-" + f.name.replace(/\.html?$/i, "").toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const app = { id, gh: RAW + f.name, src: "/static/apps/none.html" };
      try { await check(app); added.push({ id, name: prettify(f.name), file: f.name }); } catch { /* skip files that aren't web apps */ }
    }
    if (added.length) {
      const list = [...extras, ...added];
      await saveExtras(list);
      setExtras(list);
      setPrefs((p) => ({ ...p, installed: [...new Set([...(p.installed || []), ...added.map((a) => a.id)])] }));
    }
    return added;
  }
  async function updateAll() {
    setBusy(true);
    setNote("Checking GitHub…");
    let found = [], bad = "";
    try { found = await discover(); } catch (e) { bad = e.message; }
    for (const a of catalog.filter((x) => (installed.has(x.id) || x.id === "games") && targets(x).length)) await update(a);
    setNote((found.length ? "New apps added and installed: " + found.map((a) => a.name).join(", ") + ". " : "No new apps found. ") + "Everything installed was checked for updates." + (bad ? " (Couldn't look for new apps: " + bad + ".)" : ""));
    setBusy(false);
  }

  const list = catalog.filter((a) => (a.name + " " + a.blurb).toLowerCase().includes(q.toLowerCase()));
  const canUpdate = catalog.some((x) => installed.has(x.id) && targets(x).length);
  return (
    <div className="h-full overflow-y-auto p-4 text-gg-fg">
      <div className="mx-auto max-w-3xl">
        <h2 className="text-xl font-semibold">App Store</h2>
        <p className="mt-1 text-sm text-gg-fg2">Install the apps you want. They appear on your desktop and in the Start menu. Remove them any time; your saved data stays.</p>
        <div className="mt-3 flex flex-wrap items-end gap-2">
          <div className="min-w-0 flex-1 basis-48">
            <label htmlFor="st-q" className="text-sm font-semibold">Search apps</label>
            <input id="st-q" value={q} onChange={(e) => setQ(e.target.value)} className={`mt-1 block min-h-11 w-full border border-gg-line2 bg-gg-panel2 px-3 text-gg-fg ${ring}`} />
          </div>
          <button type="button" className={btn} onClick={updateAll} disabled={busy || !canUpdate}>{busy ? "Updating…" : "Update all from GitHub"}</button>
          {note && <p role="status" className="basis-full text-sm text-gg-fg2">{note}</p>}
        </div>
        <p className="mt-2 text-sm text-gg-fg2">{installed.size} installed. Updates come only from the official Giggle OS Apps page on GitHub, for your account only.</p>
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {list.map((a) => {
            const on = installed.has(a.id);
            return (
              <li key={a.id} className="flex flex-col gap-2 border border-gg-line bg-gg-panel2 p-3">
                <div className="flex items-start gap-3">
                  <span className="grid size-10 shrink-0 place-items-center" style={{ background: a.tint || "#808080", color: "#000" }}>{a.Icon ? <a.Icon size={22} aria-hidden="true" /> : null}</span>
                  <div className="min-w-0"><h3 className="font-semibold">{a.name}</h3><p className="text-sm text-gg-fg2">{a.blurb}</p></div>
                </div>
                <div className="mt-auto flex flex-wrap gap-2">
                  <button type="button" className={btn} aria-pressed={on} onClick={() => setInstalled(a.id, !on)}>{on ? "Remove" : "Install"}<span className="sr-only"> {a.name}</span></button>
                  {a.download && <a className={btn + " inline-flex items-center no-underline"} href={a.src} target="_blank" rel="noopener">Open on your phone<span className="sr-only"> ({a.name} on its own page)</span></a>}
                  {a.download && <button type="button" className={btn} onClick={() => saveCopy(a)}>Download file<span className="sr-only"> ({a.name} as a single file)</span></button>}
                  {on && targets(a).length > 0 && <button type="button" className={btn} onClick={() => update(a)}>Update<span className="sr-only"> {a.name}</span></button>}
                  {on && targets(a).length > 0 && <button type="button" className={btn} onClick={() => revert(a)}>Use built-in<span className="sr-only"> version of {a.name}</span></button>}
                </div>
                {a.download && <p className="text-xs text-gg-fg2">iPhone: tap Open on your phone, then Share → Add to Home Screen. It opens like an app, full screen. Android (Chrome): tap Open on your phone, then the menu → Install app; or Download file and open it from Downloads.</p>}
                {msg[a.id] && <p role="status" className="text-sm text-gg-fg2">{msg[a.id]}</p>}
              </li>
            );
          })}
        </ul>
        {list.length === 0 && <p className="mt-4 text-gg-fg2">No apps match that search.</p>}
      </div>
    </div>
  );
}
